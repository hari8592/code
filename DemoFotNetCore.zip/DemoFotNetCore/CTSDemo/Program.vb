Imports System
Imports DemoFotNetCore

Module Program
    Sub Main(args As String())
        Dim x As New Class1()

        Console.WriteLine("Hello World!")
    End Sub
End Module
