﻿using System;

namespace Casting_Conversion_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            string st4 = "str";
            double d=10.23455;
            string str = "hello";
            string str1 = "124556";
            string str2 = "hello123455";
            Func1();
            //casting from lower to higher (by default implicit casting)
            d = i;
            //explicit casting  - moving from higer to lower 
            i =(int)d;
            i = Convert.ToInt32(str1);
            Console.WriteLine("The value of i is:" + i);
            Console.WriteLine("The value of d is:" +d);
            Console.ReadLine();
        }
        static void Func1()
        {
            Console.WriteLine("From fun1()");
        }
    }
}
