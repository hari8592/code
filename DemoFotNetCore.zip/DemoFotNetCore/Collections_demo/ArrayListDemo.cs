﻿using System;
using System.Collections;

namespace Collections_demo
{
    class ArrayListDemo
    {
        static void Main(string[] args)
        {
            CountryMaster oCountryMaster = new CountryMaster();
            oCountryMaster.CountryCode = "IND";
            oCountryMaster.CountryName = "India";

            Hashtable ht = new Hashtable();
            //ht.Add(oCountryMaster.CountryCode, oCountryMaster.CountryName);

            //ht.Add(oCountryMaster.CountryCode, oCountryMaster.CountryCode);
            //string value1=(string)ht[oCountryMaster.CountryCode];
            
            ht.Add(oCountryMaster.CountryCode, oCountryMaster);
            CountryMaster temp =(CountryMaster)ht[oCountryMaster.CountryCode];
            











            //syntax:
            //ArrayList variable = new ArrayList();
            ArrayList a = new ArrayList();
            //added integer value
            a.Add(2);    // 0
            a.Add(2.34);  //1
            a.Add('c');   //2
            a.Add("string");   //3
            a.Add(true);  //4
            a.Add(false);  //5

            //browse or reading data using foreach
            foreach (var item in a)
            {
                Console.WriteLine(item);
            }
            object o1 = a[3];
            string o2 =(string)a[3];

            Console.WriteLine(o1);
            Console.WriteLine(o2);

            //value type
           // int i = 10;
           // object o;
           // int y;
           //// object o1 = 34;
           // o = i;       //boxing here [V-R] means moving from stack memory to heap memory
           // y = (int)o1;    // unboxing here [R-V] means moving from heap memory to stack memory
           // Console.WriteLine(y);


            Console.WriteLine("Hello World!");
            Console.ReadLine();
        }
    }


    //country class created 
    public class CountryMaster
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }

    }
}
