﻿using System;
using SomeCommonLogic;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            DisplayDateTime obj = new DisplayDateTime();
            Console.WriteLine("today date and time:"+obj.ShowCurrentDateTime());

            DisplaySpace c = new DisplaySpace();
            c.ShowSpace();



            Console.ReadLine();
        }
    }
}
