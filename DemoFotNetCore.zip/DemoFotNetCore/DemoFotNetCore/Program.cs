﻿using System;

[assembly:CLSCompliant(true)]
namespace DemoFotNetCore
{
    
    public class Class1
    {
        public static void Main(string[] args)
        {
            byte s1 = 13;
            //numeric
            int num = 10;
            //to store values with precision
            double num2 = 10.25;
            float num4 = 10.456f;
            decimal num3 = 10.35678M;
            //char 
            char s = 's';
            //multiple chars
            string str = "Hello World!";
            //true-false 
            bool status = false;
            //datetime
            DateTime dt;
            Guid guid;




        }
    }
}

