﻿using System;

namespace SomeCommonLogic
{
    public class DisplayDateTime
    {
        public string ShowCurrentDateTime()
        {
            return DateTime.Now.ToString();
        }
    }

    public class DisplaySpace
    {

        public void ShowSpace()
        {
            Console.WriteLine("Space is shown");
        }
    }
}
